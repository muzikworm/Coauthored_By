package com.iiitd.ap.lab4;
/*
 * @author Kunal Sharma
 * Roll number 2014054
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

class DBLP
{
	public String authorname;
    public String papertitle;
	
    BufferedReader br=null;
    String line = "";
    
    HashMap<String,ArrayList<String>> map = new HashMap<String,ArrayList<String>>();
    public void data()  {
    	try {

    		br = new BufferedReader(new FileReader("./src/output.csv"));
    		while ((line = br.readLine()) != null) {

    		        // use comma as separator
    			String[] details = line.split(",");
    			authorname=details[0];
    			papertitle=details[1];
    			if(map.containsKey(authorname)==false)
    			{
    				ArrayList<String> title =new ArrayList<String>();
    				title.add(papertitle);
    				map.put(authorname,title);
    				
    			}
    			else
    			{
    				ArrayList<String> title =new ArrayList<String>();
    				title=map.get(authorname);
    				map.remove(authorname);
    				title.add(papertitle);
    				map.put(authorname,title);
    				
    			}
    			
    		}
    		}// end of try
    	catch (FileNotFoundException e) {
    		e.printStackTrace();
    	} catch (IOException e) {
    		e.printStackTrace();
    	} finally {
    		if (br != null) {
    			try {
    				br.close();
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    		}
    	}
    	
    	
    	
    	
    }//end of data
    public ArrayList<String> coauthored(String author1,String author2)
    {
    	data();
     ArrayList<String> ret,a1,a2 ;
       a1= map.get(author1);
       a2=map.get(author2);
       ret =new ArrayList<String>();
       for(int i=0;i<a1.size();i++)
       {
    	   String temp=a1.get(i);
    	   if(a2.contains(temp)==true)
    	   {
    		   ret.add(temp);
    	   }
    	   
       }
	  return ret;
    }
    
}


